Tiger Sierra Theme Version 2
by swamprock -- AmazingHenry -- AphoticD -- zappaesque
with help from the members of the MacRumors PowerPC forum
https://forums.macrumors.com/forums/powerpc-macs.145

PLEASE READ THIS ENTIRE DOCUMENT BEFORE INSTALLING!

This package is completely FREE and offered with NO WARRANTY. Installation and use of this theme package is done at the user's OWN RISK. The contributors to this project are in no way responsible if your system installation is damaged by use or misuse. It is recommended that you completely backup any system that this theme will be installed on. It is NOT recommended that this theme be installed on a production system. Although extensive testing has been done with the installation and uninstallation of this theme, mishaps do occur. Please backup your system before installing.

...and please, don't mess with the install and uninstall scripts unless you know what you're doing!

SYSTEM REQUIREMENTS:

A PowerPC Macintosh running a fully-updated installation of Mac OS X 10.4.11. As this release doesn't modify any extra applications (iTunes, etc.), there is no need to be completely up-to-date with those applications, or with Java. The effects of installing this theme on a system below these requirements is unknown, and is done at YOUR OWN RISK.

INSTALLATION:

0. CLOSE ALL APPLICATIONS!

1. Unzip TigerSierraTheme-ver2.zip to the Desktop.

2. Open a Terminal window (/Applications/Utilities/Terminal)

3. Type "cd" (without the quotes) and hit the space bar once.

4. Drag the TigerSierraTheme folder to the Terminal window and hit Return.

5. Type "sudo ./install.sh" (sans quotes) and hit Return.

6. Enter your user password (if required) and hit Return.

7. Follow the prompts.

8. You will have a choice of whether to replace your Lucida Grande font with the San Francisco font. You will lose use of the original Lucida Grande font if you choose to install San Francisco, but the theme will look a bit more accurate with it installed.

9. DO NOT OPEN ANY APPS, POWER DOWN THE SYSTEM, CLOSE THE TERMINAL WINDOW, OR OTHERWISE INTERRUPT THE INSTALLATION PROCESS!!!

10. Once the resources are installed, the system will perform a permissions repair. Let it finish.

11. Your system will reboot automatically once the installation is complete.

12. Enjoy your Sierra-themed Tiger installation!

UNINSTALLATION:

0. CLOSE ALL APPLICATIONS!

1. Follow steps 1-4 above.

2. Type "sudo ./uninstall.sh" (sans quotes) and hit Return.

3. Enter your user password (if required) and hit Return.

4. Follow the prompts.

5. DO NOT OPEN ANY APPS, POWER DOWN THE SYSTEM, CLOSE THE TERMINAL WINDOW, OR OTHERWISE INTERRUPT THE RESTORATION PROCESS!!!

6. Your system will perform a permissions repair, then reboot automatically upon completion of the restoration.

7. Enjoy the splendor of Aqua once again!

INSTALLING ICONS:

You will need to download and install CandyBar 2.6.1, update it, then register it. There are two iContainer packages included in this theme package that you can load into CandyBar that will change many of your System and Applications icons. As these packages do not contain every application icon known to man, there are manual ways to change the icons. Members of the PowerPC forums at macrumors.com (linked at the top of this document) can help with this.

OTHER RESOURCES:

There are a number of applications that you can install that approximate later macOS functionality. Here is a short list:

RapidOStart- Launchpad
MacGizmo- Quicklook
xPad- Notes
ImagineBootX- change boot screen
ClearDock- change Dock color/transparancy
MenuShade- add transparancy to the menu bar
PPCAppStore- an app store for PowerPC!

These apps can be easily found by searching for them. A few sites to check out are:

PowerPC Archive- http://ppcarchive.dyniform.net/software.html
Mac PowerPC- https://macpowerpc.com/
PPCAppStore- https://ppcappstore.wordpress.com/

TROUBLESHOOTING:

1. If you see the error "rm: /Users/<your user name>/Library/Caches/com.apple.preferencepanes.cache: No such file or directory", it is completely normal and nothing to worry about.

2. If you get an error that the install or uninstall scripts are not found, you'll have to set them to execute by typing "sudo chmod +x install.sh" and "sudo chmod +x uninstall.sh" (sans quotes). This will allow them to run on your system.

CREDITS:

swamprock- theming work, sidebar icons, some applications and system icons, font conversion, install and uninstall scripting

AmazingHenry- original theme release with some tweaks, testing

AphoticD- preliminary installation script, Spotlight icon fix, icons, testing

zappaesque- gathering of list of apps approximating later macOS functionality, some icons, WaitingForLoginWindow info, testing

THANKS:
gavinstubbs09- the original theme guru and PowerPC Archive webmaster
SourceSunTom- LeopardRebirth theme author
Dronecatcher- for his support
z970mp- ditto
All of the other great folks at the MacRumors PowerPC forum, many of whom shared ideas and work of their own. Thanks!