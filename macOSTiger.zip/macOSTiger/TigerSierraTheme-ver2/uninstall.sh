#/bin/sh
clear
echo "Tiger Sierra Theme - Version 2"
echo "by swamprock -- AmazingHenry -- AphoticD -- zappaesque"
echo "with help from the members of the MacRumors PowerPC forum"
echo "https://forums.macrumors.com/forums/powerpc-macs.145"
echo " "
echo "Please close ALL applications other than Terminal while your files are restored."
echo "ONCE THE RESTORATION STARTS, DO NOT STOP THE PROCESS! YOUR SYSTEM WILL BE HOSED IF YOU DO!"
echo "Your system will reboot automatically when the restoration is finished."
echo " "

while true
do
	read -p "Are you sure that you want to uninstall the Tiger Sierra Theme (y/n)?" answer

	case $answer in
		[yY]* )
clear 
echo "Removing Tiger Sierra Theme and restoring Aqua resources..."

# Restore Extras.rsrc
rm /System/Library/Frameworks/Carbon.framework/Versions/A/Frameworks/HIToolbox.framework/Versions/A/Resources/Extras.rsrc

mv  /System/Library/Frameworks/Carbon.framework/Versions/A/Frameworks/HIToolbox.framework/Versions/A/Resources/Extras.rsrc.backup /System/Library/Frameworks/Carbon.framework/Versions/A/Frameworks/HIToolbox.framework/Versions/A/Resources/Extras.rsrc

# Restore Finder.rsrc
rm /System/Library/CoreServices/Finder.app/Contents/Resources/Finder.rsrc 

mv /System/Library/CoreServices/Finder.app/Contents/Resources/Finder.rsrc.backup /System/Library/CoreServices/Finder.app/Contents/Resources/Finder.rsrc

# Restore Spotlight icons
rm /System/Library/CoreServices/Search.bundle/Contents/Resources/MDSearchWidget_Normal-1.tiff

mv /System/Library/CoreServices/Search.bundle/Contents/Resources/MDSearchWidget_Normal-1.tiff.backup /System/Library/CoreServices/Search.bundle/Contents/Resources/MDSearchWidget_Normal-1.tiff

rm /System/Library/CoreServices/Search.bundle/Contents/Resources/MDSearchWidget_Normal-6.tiff

mv /System/Library/CoreServices/Search.bundle/Contents/Resources/MDSearchWidget_Normal-6.tiff.backup /System/Library/CoreServices/Search.bundle/Contents/Resources/MDSearchWidget_Normal-6.tiff 

rm /System/Library/CoreServices/Search.bundle/Contents/Resources/MDSearchWidget_Pressed-1.tiff

mv /System/Library/CoreServices/Search.bundle/Contents/Resources/MDSearchWidget_Pressed-1.tiff.backup /System/Library/CoreServices/Search.bundle/Contents/Resources/MDSearchWidget_Pressed-1.tiff

rm /System/Library/CoreServices/Search.bundle/Contents/Resources/MDSearchWidget_Pressed-6.tiff

mv /System/Library/CoreServices/Search.bundle/Contents/Resources/MDSearchWidget_Pressed-6.tiff.backup /System/Library/CoreServices/Search.bundle/Contents/Resources/MDSearchWidget_Pressed-6.tiff

# Restore AboutThisMac nib and strings

rm /System/Library/CoreServices/loginwindow.app/Contents/Resources/English.lproj/AboutThisMac.nib/classes.nib

rm /System/Library/CoreServices/loginwindow.app/Contents/Resources/English.lproj/AboutThisMac.nib/info.nib

rm /System/Library/CoreServices/loginwindow.app/Contents/Resources/English.lproj/AboutThisMac.nib/keyedobjects.nib

rm /System/Library/CoreServices/loginwindow.app/Contents/Resources/English.lproj/AboutThisMac.strings

mv /System/Library/CoreServices/loginwindow.app/Contents/Resources/English.lproj/AboutThisMac.nib/classes.nib.backup /System/Library/CoreServices/loginwindow.app/Contents/Resources/English.lproj/AboutThisMac.nib/classes.nib

mv /System/Library/CoreServices/loginwindow.app/Contents/Resources/English.lproj/AboutThisMac.nib/info.nib.backup /System/Library/CoreServices/loginwindow.app/Contents/Resources/English.lproj/AboutThisMac.nib/info.nib

mv /System/Library/CoreServices/loginwindow.app/Contents/Resources/English.lproj/AboutThisMac.nib/keyedobjects.nib.backup /System/Library/CoreServices/loginwindow.app/Contents/Resources/English.lproj/AboutThisMac.nib/keyedobjects.nib

mv /System/Library/CoreServices/loginwindow.app/Contents/Resources/English.lproj/AboutThisMac.strings.backup /System/Library/CoreServices/loginwindow.app/Contents/Resources/English.lproj/AboutThisMac.strings

# Restore SecurityAgent tifs

rm /System/Library/CoreServices/SecurityAgent.app/Contents/Resources/applelogo.tif

rm /System/Library/CoreServices/SecurityAgent.app/Contents/Resources/gotoH.tif

rm /System/Library/CoreServices/SecurityAgent.app/Contents/Resources/gotoN.tif

rm /System/Library/CoreServices/SecurityAgent.app/Contents/Resources/homeH.tif

rm /System/Library/CoreServices/SecurityAgent.app/Contents/Resources/homeN.tif

rm /System/Library/CoreServices/SecurityAgent.app/Contents/Resources/MacOSX.tif

rm /System/Library/CoreServices/SecurityAgent.app/Contents/Resources/restartH.tif

rm /System/Library/CoreServices/SecurityAgent.app/Contents/Resources/restartN.tif

rm /System/Library/CoreServices/SecurityAgent.app/Contents/Resources/shutdownH.tif

rm /System/Library/CoreServices/SecurityAgent.app/Contents/Resources/shutdownN.tif

rm /System/Library/CoreServices/SecurityAgent.app/Contents/Resources/sleepH.tif

rm /System/Library/CoreServices/SecurityAgent.app/Contents/Resources/sleepN.tif

mv /System/Library/CoreServices/SecurityAgent.app/Contents/Resources/applelogo.tif.backup /System/Library/CoreServices/SecurityAgent.app/Contents/Resources/applelogo.tif

mv /System/Library/CoreServices/SecurityAgent.app/Contents/Resources/gotoH.tif.backup /System/Library/CoreServices/SecurityAgent.app/Contents/Resources/gotoH.tif

mv /System/Library/CoreServices/SecurityAgent.app/Contents/Resources/gotoN.tif.backup /System/Library/CoreServices/SecurityAgent.app/Contents/Resources/gotoN.tif

mv /System/Library/CoreServices/SecurityAgent.app/Contents/Resources/homeH.tif.backup /System/Library/CoreServices/SecurityAgent.app/Contents/Resources/homeH.tif

mv /System/Library/CoreServices/SecurityAgent.app/Contents/Resources/homeN.tif.backup /System/Library/CoreServices/SecurityAgent.app/Contents/Resources/homeN.tif

mv /System/Library/CoreServices/SecurityAgent.app/Contents/Resources/MacOSX.tif.backup /System/Library/CoreServices/SecurityAgent.app/Contents/Resources/MacOSX.tif

mv /System/Library/CoreServices/SecurityAgent.app/Contents/Resources/restartH.tif.backup /System/Library/CoreServices/SecurityAgent.app/Contents/Resources/restartH.tif

mv /System/Library/CoreServices/SecurityAgent.app/Contents/Resources/restartN.tif.backup /System/Library/CoreServices/SecurityAgent.app/Contents/Resources/restartN.tif

mv /System/Library/CoreServices/SecurityAgent.app/Contents/Resources/shutdownH.tif.backup /System/Library/CoreServices/SecurityAgent.app/Contents/Resources/shutdownH.tif

mv /System/Library/CoreServices/SecurityAgent.app/Contents/Resources/shutdownN.tif.backup /System/Library/CoreServices/SecurityAgent.app/Contents/Resources/shutdownN.tif

mv /System/Library/CoreServices/SecurityAgent.app/Contents/Resources/sleepH.tif.backup /System/Library/CoreServices/SecurityAgent.app/Contents/Resources/sleepH.tif

mv /System/Library/CoreServices/SecurityAgent.app/Contents/Resources/sleepN.tif.backup /System/Library/CoreServices/SecurityAgent.app/Contents/Resources/sleepN.tif

# Restore loginwindow tif
rm /System/Library/CoreServices/loginwindow.app/Contents/Resources/MacOSX.tif

mv /System/Library/CoreServices/loginwindow.app/Contents/Resources/MacOSX.tif.backup /System/Library/CoreServices/loginwindow.app/Contents/Resources/MacOSX.tif

# Restore System Preferences Back/Forward Arrows
rm /Applications/System\ Preferences.app/Contents/Resources/BackAdorn.png

rm /Applications/System\ Preferences.app/Contents/Resources/ForwardAdorn.png

mv /Applications/System\ Preferences.app/Contents/Resources/BackAdorn.png.backup /Applications/System\ Preferences.app/Contents/Resources/BackAdorn.png

mv /Applications/System\ Preferences.app/Contents/Resources/ForwardAdorn.png.backup /Applications/System\ Preferences.app/Contents/Resources/ForwardAdorn.png

# Backup and Install PrefPane icons

rm /System/Library/PreferencePanes/Accounts.prefPane/Contents/Resources/AccountsPref.icns

rm /System/Library/PreferencePanes/Bluetooth.prefPane/Contents/Resources/BluetoothPref.icns

rm /System/Library/PreferencePanes/DateAndTime.prefPane/Contents/Resources/DateAndTime.icns

rm /System/Library/PreferencePanes/DesktopScreenEffectsPref.prefPane/Contents/Resources/DesktopScreenEffectsPref.icns

rm /System/Library/PreferencePanes/Displays.prefPane/Contents/Resources/Displays.icns

rm /System/Library/PreferencePanes/Dock.prefPane/Contents/Resources/Dock.icns

rm /System/Library/PreferencePanes/EnergySaver.prefPane/Contents/Resources/EnergySaver.icns

rm /System/Library/PreferencePanes/Expose.prefPane/Contents/Resources/Expose.icns

rm /System/Library/PreferencePanes/Security.prefPane/Contents/Resources/FileVault.icns

rm /System/Library/PreferencePanes/Appearance.prefPane/Contents/Resources/General.icns

rm /System/Library/PreferencePanes/Keyboard.prefPane/Contents/Resources/Keyboard.icns

rm /System/Library/PreferencePanes/Localization.prefPane/Contents/Resources/Localization.icns

rm /System/Library/PreferencePanes/PrintAndFax.prefPane/Contents/Resources/PrintFaxPref.icns

rm /System/Library/PreferencePanes/SharingPref.prefPane/Contents/Resources/SharingPref.icns

rm /System/Library/PreferencePanes/Sound.prefPane/Contents/Resources/SoundPref.icns

rm /System/Library/PreferencePanes/StartupDisk.prefPane/Contents/Resources/StartupDiskPref.icns

rm /System/Library/PreferencePanes/UniversalAccessPref.prefPane/Contents/Resources/UniversalAccessPref.icns

mv /System/Library/PreferencePanes/Accounts.prefPane/Contents/Resources/AccountsPref.icns.backup /System/Library/PreferencePanes/Accounts.prefPane/Contents/Resources/AccountsPref.icns

mv /System/Library/PreferencePanes/Bluetooth.prefPane/Contents/Resources/BluetoothPref.icns.backup /System/Library/PreferencePanes/Bluetooth.prefPane/Contents/Resources/BluetoothPref.icns

mv /System/Library/PreferencePanes/DateAndTime.prefPane/Contents/Resources/DateAndTime.icns.backup /System/Library/PreferencePanes/DateAndTime.prefPane/Contents/Resources/DateAndTime.icns

mv /System/Library/PreferencePanes/DesktopScreenEffectsPref.prefPane/Contents/Resources/DesktopScreenEffectsPref.icns.backup /System/Library/PreferencePanes/DesktopScreenEffectsPref.prefPane/Contents/Resources/DesktopScreenEffectsPref.icns

mv /System/Library/PreferencePanes/Displays.prefPane/Contents/Resources/Displays.icns.backup /System/Library/PreferencePanes/Displays.prefPane/Contents/Resources/Displays.icns

mv /System/Library/PreferencePanes/Dock.prefPane/Contents/Resources/Dock.icns.backup /System/Library/PreferencePanes/Dock.prefPane/Contents/Resources/Dock.icns

mv /System/Library/PreferencePanes/EnergySaver.prefPane/Contents/Resources/EnergySaver.icns.backup /System/Library/PreferencePanes/EnergySaver.prefPane/Contents/Resources/EnergySaver.icns

mv /System/Library/PreferencePanes/Expose.prefPane/Contents/Resources/Expose.icns.backup /System/Library/PreferencePanes/Expose.prefPane/Contents/Resources/Expose.icns

mv /System/Library/PreferencePanes/Security.prefPane/Contents/Resources/FileVault.icns.backup /System/Library/PreferencePanes/Security.prefPane/Contents/Resources/FileVault.icns

mv /System/Library/PreferencePanes/Appearance.prefPane/Contents/Resources/General.icns.backup /System/Library/PreferencePanes/Appearance.prefPane/Contents/Resources/General.icns

mv /System/Library/PreferencePanes/Keyboard.prefPane/Contents/Resources/Keyboard.icns.backup /System/Library/PreferencePanes/Keyboard.prefPane/Contents/Resources/Keyboard.icns

mv /System/Library/PreferencePanes/Localization.prefPane/Contents/Resources/Localization.icns.backup /System/Library/PreferencePanes/Localization.prefPane/Contents/Resources/Localization.icns

mv /System/Library/PreferencePanes/PrintAndFax.prefPane/Contents/Resources/PrintFaxPref.icns.backup /System/Library/PreferencePanes/PrintAndFax.prefPane/Contents/Resources/PrintFaxPref.icns

mv /System/Library/PreferencePanes/SharingPref.prefPane/Contents/Resources/SharingPref.icns.backup /System/Library/PreferencePanes/SharingPref.prefPane/Contents/Resources/SharingPref.icns

mv /System/Library/PreferencePanes/Sound.prefPane/Contents/Resources/SoundPref.icns.backup /System/Library/PreferencePanes/Sound.prefPane/Contents/Resources/SoundPref.icns

mv /System/Library/PreferencePanes/StartupDisk.prefPane/Contents/Resources/StartupDiskPref.icns.backup /System/Library/PreferencePanes/StartupDisk.prefPane/Contents/Resources/StartupDiskPref.icns

mv /System/Library/PreferencePanes/UniversalAccessPref.prefPane/Contents/Resources/UniversalAccessPref.icns.backup /System/Library/PreferencePanes/UniversalAccessPref.prefPane/Contents/Resources/UniversalAccessPref.icns

# Flush System Preferences icon cache
rm ~/Library/Caches/com.apple.preferencepanes.cache

#Set correct ownership permissions
chown -R root\:wheel /System/Library/PreferencePanes

# Restore WaitingForLoginWindow
mv /usr/libexec/WaitingForLoginWindow.backup /usr/libexec/WaitingForLoginWindow

echo "Aqua resources are restored."
break;;

[nN]* ) exit;;
* ) echo "y/n answer please.";;
esac
done

# Test if font was replaced and restore if true

file="/System/Library/Fonts/LucidaGrande.dfont.backup"
if [ -f "$file" ]
then
	rm /System/Library/Fonts/LucidaGrande.dfont
	
	mv /System/Library/Fonts/LucidaGrande.dfont.backup /System/Library/Fonts/LucidaGrande.dfont
	echo "Font restored."
else
	echo "Font not changed. No restoration necessary."
fi

# Repair disk permissions
diskutil repairPermissions /
clear
echo "Your system is restored. Rebooting..."
sleep 10
reboot