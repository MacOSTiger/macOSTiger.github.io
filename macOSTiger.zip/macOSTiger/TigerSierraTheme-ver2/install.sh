#/bin/sh

clear
echo "Tiger Sierra Theme - Version 2"
echo "by swamprock -- AmazingHenry -- AphoticD -- zappaesque"
echo "with help from the members of the MacRumors PowerPC forum"
echo "https://forums.macrumors.com/forums/powerpc-macs.145"
echo " "
echo "Please close ALL applications other than Terminal while the theme installs."
echo "ONCE THE INSTALLATION STARTS, DO NOT STOP THE PROCESS! YOUR SYSTEM WILL BE HOSED IF YOU DO!"
echo "Your system will reboot automatically when the installation is finished."
echo " "

while true
do
	read -p "Are you sure that you want to install the Tiger Sierra Theme (y/n)?" answer

	case $answer in
		[yY]* )
clear 
echo "Backing up original resources and installing files..."
# Backup and Install Extras.rsrc
mv /System/Library/Frameworks/Carbon.framework/Versions/A/Frameworks/HIToolbox.framework/Versions/A/Resources/Extras.rsrc /System/Library/Frameworks/Carbon.framework/Versions/A/Frameworks/HIToolbox.framework/Versions/A/Resources/Extras.rsrc.backup

cp ./Extras.rsrc /System/Library/Frameworks/Carbon.framework/Versions/A/Frameworks/HIToolbox.framework/Versions/A/Resources/Extras.rsrc

# Backup and Install Finder.rsrc
mv /System/Library/CoreServices/Finder.app/Contents/Resources/Finder.rsrc /System/Library/CoreServices/Finder.app/Contents/Resources/Finder.rsrc.backup

cp ./Finder.rsrc /System/Library/CoreServices/Finder.app/Contents/Resources/Finder.rsrc

# Backup and install Spotlight icons
mv /System/Library/CoreServices/Search.bundle/Contents/Resources/MDSearchWidget_Normal-1.tiff /System/Library/CoreServices/Search.bundle/Contents/Resources/MDSearchWidget_Normal-1.tiff.backup

mv /System/Library/CoreServices/Search.bundle/Contents/Resources/MDSearchWidget_Normal-6.tiff /System/Library/CoreServices/Search.bundle/Contents/Resources/MDSearchWidget_Normal-6.tiff.backup

mv /System/Library/CoreServices/Search.bundle/Contents/Resources/MDSearchWidget_Pressed-1.tiff /System/Library/CoreServices/Search.bundle/Contents/Resources/MDSearchWidget_Pressed-1.tiff.backup

mv /System/Library/CoreServices/Search.bundle/Contents/Resources/MDSearchWidget_Pressed-6.tiff /System/Library/CoreServices/Search.bundle/Contents/Resources/MDSearchWidget_Pressed-6.tiff.backup

cp ./searchbundle/MDSearchWidget_Normal-1.tiff /System/Library/CoreServices/Search.bundle/Contents/Resources/MDSearchWidget_Normal-1.tiff

cp ./searchbundle/MDSearchWidget_Normal-6.tiff /System/Library/CoreServices/Search.bundle/Contents/Resources/MDSearchWidget_Normal-6.tiff

cp ./searchbundle/MDSearchWidget_Pressed-1.tiff /System/Library/CoreServices/Search.bundle/Contents/Resources/MDSearchWidget_Pressed-1.tiff

cp ./searchbundle/MDSearchWidget_Pressed-6.tiff /System/Library/CoreServices/Search.bundle/Contents/Resources/MDSearchWidget_Pressed-6.tiff

# Backup and Install AboutThisMac nib and strings

mv /System/Library/CoreServices/loginwindow.app/Contents/Resources/English.lproj/AboutThisMac.nib/classes.nib /System/Library/CoreServices/loginwindow.app/Contents/Resources/English.lproj/AboutThisMac.nib/classes.nib.backup

mv /System/Library/CoreServices/loginwindow.app/Contents/Resources/English.lproj/AboutThisMac.nib/info.nib /System/Library/CoreServices/loginwindow.app/Contents/Resources/English.lproj/AboutThisMac.nib/info.nib.backup

mv /System/Library/CoreServices/loginwindow.app/Contents/Resources/English.lproj/AboutThisMac.nib/keyedobjects.nib /System/Library/CoreServices/loginwindow.app/Contents/Resources/English.lproj/AboutThisMac.nib/keyedobjects.nib.backup

mv /System/Library/CoreServices/loginwindow.app/Contents/Resources/English.lproj/AboutThisMac.strings /System/Library/CoreServices/loginwindow.app/Contents/Resources/English.lproj/AboutThisMac.strings.backup

cp ./abouthismac/AboutThisMac.nib/classes.nib /System/Library/CoreServices/loginwindow.app/Contents/Resources/English.lproj/AboutThisMac.nib/classes.nib

cp ./abouthismac/AboutThisMac.nib/info.nib /System/Library/CoreServices/loginwindow.app/Contents/Resources/English.lproj/AboutThisMac.nib/info.nib

cp ./abouthismac/AboutThisMac.nib/keyedobjects.nib /System/Library/CoreServices/loginwindow.app/Contents/Resources/English.lproj/AboutThisMac.nib/keyedobjects.nib

cp ./abouthismac/AboutThisMac.strings /System/Library/CoreServices/loginwindow.app/Contents/Resources/English.lproj/AboutThisMac.strings

# Backup and Install SecurityAgent tifs

mv /System/Library/CoreServices/SecurityAgent.app/Contents/Resources/applelogo.tif /System/Library/CoreServices/SecurityAgent.app/Contents/Resources/applelogo.tif.backup

mv /System/Library/CoreServices/SecurityAgent.app/Contents/Resources/gotoH.tif /System/Library/CoreServices/SecurityAgent.app/Contents/Resources/gotoH.tif.backup

mv /System/Library/CoreServices/SecurityAgent.app/Contents/Resources/gotoN.tif /System/Library/CoreServices/SecurityAgent.app/Contents/Resources/gotoN.tif.backup

mv /System/Library/CoreServices/SecurityAgent.app/Contents/Resources/homeH.tif /System/Library/CoreServices/SecurityAgent.app/Contents/Resources/homeH.tif.backup

mv /System/Library/CoreServices/SecurityAgent.app/Contents/Resources/homeN.tif /System/Library/CoreServices/SecurityAgent.app/Contents/Resources/homeN.tif.backup

mv /System/Library/CoreServices/SecurityAgent.app/Contents/Resources/MacOSX.tif /System/Library/CoreServices/SecurityAgent.app/Contents/Resources/MacOSX.tif.backup

mv /System/Library/CoreServices/SecurityAgent.app/Contents/Resources/restartH.tif /System/Library/CoreServices/SecurityAgent.app/Contents/Resources/restartH.tif.backup

mv /System/Library/CoreServices/SecurityAgent.app/Contents/Resources/restartN.tif /System/Library/CoreServices/SecurityAgent.app/Contents/Resources/restartN.tif.backup

mv /System/Library/CoreServices/SecurityAgent.app/Contents/Resources/shutdownH.tif /System/Library/CoreServices/SecurityAgent.app/Contents/Resources/shutdownH.tif.backup

mv /System/Library/CoreServices/SecurityAgent.app/Contents/Resources/shutdownN.tif /System/Library/CoreServices/SecurityAgent.app/Contents/Resources/shutdownN.tif.backup

mv /System/Library/CoreServices/SecurityAgent.app/Contents/Resources/sleepH.tif /System/Library/CoreServices/SecurityAgent.app/Contents/Resources/sleepH.tif.backup

mv /System/Library/CoreServices/SecurityAgent.app/Contents/Resources/sleepN.tif /System/Library/CoreServices/SecurityAgent.app/Contents/Resources/sleepN.tif.backup

cp ./securityagent/applelogo.tif /System/Library/CoreServices/SecurityAgent.app/Contents/Resources/applelogo.tif

cp ./securityagent/gotoH.tif /System/Library/CoreServices/SecurityAgent.app/Contents/Resources/gotoH.tif

cp ./securityagent/gotoN.tif /System/Library/CoreServices/SecurityAgent.app/Contents/Resources/gotoN.tif

cp ./securityagent/homeH.tif /System/Library/CoreServices/SecurityAgent.app/Contents/Resources/homeH.tif

cp ./securityagent/homeN.tif /System/Library/CoreServices/SecurityAgent.app/Contents/Resources/homeN.tif

cp ./securityagent/MacOSX.tif /System/Library/CoreServices/SecurityAgent.app/Contents/Resources/MacOSX.tif

cp ./securityagent/restartH.tif /System/Library/CoreServices/SecurityAgent.app/Contents/Resources/restartH.tif

cp ./securityagent/restartN.tif /System/Library/CoreServices/SecurityAgent.app/Contents/Resources/restartN.tif

cp ./securityagent/shutdownH.tif /System/Library/CoreServices/SecurityAgent.app/Contents/Resources/shutdownH.tif

cp ./securityagent/shutdownN.tif /System/Library/CoreServices/SecurityAgent.app/Contents/Resources/shutdownN.tif

cp ./securityagent/sleepH.tif /System/Library/CoreServices/SecurityAgent.app/Contents/Resources/sleepH.tif

cp ./securityagent/sleepN.tif /System/Library/CoreServices/SecurityAgent.app/Contents/Resources/sleepN.tif

# Backup and Install loginwindow tif

mv /System/Library/CoreServices/loginwindow.app/Contents/Resources/MacOSX.tif /System/Library/CoreServices/loginwindow.app/Contents/Resources/MacOSX.tif.backup

cp ./loginwindow/MacOSX.tif /System/Library/CoreServices/loginwindow.app/Contents/Resources/MacOSX.tif

# Backup and Install System Preferences Back/Forward Arrows
mv /Applications/System\ Preferences.app/Contents/Resources/BackAdorn.png /Applications/System\ Preferences.app/Contents/Resources/BackAdorn.png.backup

cp ./sysprefarrows/BackAdorn.png /Applications/System\ Preferences.app/Contents/Resources/BackAdorn.png

mv /Applications/System\ Preferences.app/Contents/Resources/ForwardAdorn.png /Applications/System\ Preferences.app/Contents/Resources/ForwardAdorn.png.backup

cp ./sysprefarrows/ForwardAdorn.png /Applications/System\ Preferences.app/Contents/Resources/ForwardAdorn.png

# Backup and Install PrefPane icons

mv /System/Library/PreferencePanes/Accounts.prefPane/Contents/Resources/AccountsPref.icns /System/Library/PreferencePanes/Accounts.prefPane/Contents/Resources/AccountsPref.icns.backup

mv /System/Library/PreferencePanes/Bluetooth.prefPane/Contents/Resources/BluetoothPref.icns /System/Library/PreferencePanes/Bluetooth.prefPane/Contents/Resources/BluetoothPref.icns.backup

mv /System/Library/PreferencePanes/DateAndTime.prefPane/Contents/Resources/DateAndTime.icns /System/Library/PreferencePanes/DateAndTime.prefPane/Contents/Resources/DateAndTime.icns.backup

mv /System/Library/PreferencePanes/DesktopScreenEffectsPref.prefPane/Contents/Resources/DesktopScreenEffectsPref.icns /System/Library/PreferencePanes/DesktopScreenEffectsPref.prefPane/Contents/Resources/DesktopScreenEffectsPref.icns.backup

mv /System/Library/PreferencePanes/Displays.prefPane/Contents/Resources/Displays.icns /System/Library/PreferencePanes/Displays.prefPane/Contents/Resources/Displays.icns.backup

mv /System/Library/PreferencePanes/Dock.prefPane/Contents/Resources/Dock.icns /System/Library/PreferencePanes/Dock.prefPane/Contents/Resources/Dock.icns.backup

mv /System/Library/PreferencePanes/EnergySaver.prefPane/Contents/Resources/EnergySaver.icns /System/Library/PreferencePanes/EnergySaver.prefPane/Contents/Resources/EnergySaver.icns.backup

mv /System/Library/PreferencePanes/Expose.prefPane/Contents/Resources/Expose.icns /System/Library/PreferencePanes/Expose.prefPane/Contents/Resources/Expose.icns.backup

mv /System/Library/PreferencePanes/Security.prefPane/Contents/Resources/FileVault.icns /System/Library/PreferencePanes/Security.prefPane/Contents/Resources/FileVault.icns.backup

mv /System/Library/PreferencePanes/Appearance.prefPane/Contents/Resources/General.icns /System/Library/PreferencePanes/Appearance.prefPane/Contents/Resources/General.icns.backup

mv /System/Library/PreferencePanes/Keyboard.prefPane/Contents/Resources/Keyboard.icns /System/Library/PreferencePanes/Keyboard.prefPane/Contents/Resources/Keyboard.icns.backup

mv /System/Library/PreferencePanes/Localization.prefPane/Contents/Resources/Localization.icns /System/Library/PreferencePanes/Localization.prefPane/Contents/Resources/Localization.icns.backup

mv /System/Library/PreferencePanes/PrintAndFax.prefPane/Contents/Resources/PrintFaxPref.icns /System/Library/PreferencePanes/PrintAndFax.prefPane/Contents/Resources/PrintFaxPref.icns.backup

mv /System/Library/PreferencePanes/SharingPref.prefPane/Contents/Resources/SharingPref.icns /System/Library/PreferencePanes/SharingPref.prefPane/Contents/Resources/SharingPref.icns.backup

mv /System/Library/PreferencePanes/Sound.prefPane/Contents/Resources/SoundPref.icns /System/Library/PreferencePanes/Sound.prefPane/Contents/Resources/SoundPref.icns.backup

mv /System/Library/PreferencePanes/StartupDisk.prefPane/Contents/Resources/StartupDiskPref.icns /System/Library/PreferencePanes/StartupDisk.prefPane/Contents/Resources/StartupDiskPref.icns.backup

mv /System/Library/PreferencePanes/UniversalAccessPref.prefPane/Contents/Resources/UniversalAccessPref.icns /System/Library/PreferencePanes/UniversalAccessPref.prefPane/Contents/Resources/UniversalAccessPref.icns.backup

cp ./preficons/AccountsPref.icns /System/Library/PreferencePanes/Accounts.prefPane/Contents/Resources/AccountsPref.icns

cp ./preficons/BluetoothPref.icns /System/Library/PreferencePanes/Bluetooth.prefPane/Contents/Resources/BluetoothPref.icns

cp ./preficons/DateAndTime.icns /System/Library/PreferencePanes/DateAndTime.prefPane/Contents/Resources/DateAndTime.icns

cp ./preficons/DateAndTime.icns /System/Library/PreferencePanes/DateAndTime.prefPane/Contents/Resources/DateAndTime.icns

cp ./preficons/DesktopScreenEffectsPref.icns /System/Library/PreferencePanes/DesktopScreenEffectsPref.prefPane/Contents/Resources/DesktopScreenEffectsPref.icns

cp ./preficons/Displays.icns /System/Library/PreferencePanes/Displays.prefPane/Contents/Resources/Displays.icns

cp ./preficons/Dock.icns /System/Library/PreferencePanes/Dock.prefPane/Contents/Resources/Dock.icns

cp ./preficons/EnergySaver.icns /System/Library/PreferencePanes/EnergySaver.prefPane/Contents/Resources/EnergySaver.icns

cp ./preficons/Expose.icns /System/Library/PreferencePanes/Expose.prefPane/Contents/Resources/Expose.icns

cp ./preficons/FileVault.icns /System/Library/PreferencePanes/Security.prefPane/Contents/Resources/FileVault.icns

cp ./preficons/General.icns /System/Library/PreferencePanes/Appearance.prefPane/Contents/Resources/General.icns

cp ./preficons/Keyboard.icns /System/Library/PreferencePanes/Keyboard.prefPane/Contents/Resources/Keyboard.icns

cp ./preficons/Localization.icns /System/Library/PreferencePanes/Localization.prefPane/Contents/Resources/Localization.icns

cp ./preficons/PrintFaxPref.icns /System/Library/PreferencePanes/PrintAndFax.prefPane/Contents/Resources/PrintFaxPref.icns

cp ./preficons/SharingPref.icns /System/Library/PreferencePanes/SharingPref.prefPane/Contents/Resources/SharingPref.icns

cp ./preficons/SoundPref.icns /System/Library/PreferencePanes/Sound.prefPane/Contents/Resources/SoundPref.icns

cp ./preficons/StartupDiskPref.icns /System/Library/PreferencePanes/StartupDisk.prefPane/Contents/Resources/StartupDiskPref.icns

cp ./preficons/UniversalAccessPref.icns /System/Library/PreferencePanes/UniversalAccessPref.prefPane/Contents/Resources/UniversalAccessPref.icns

# Flush System Preferences icon cache
rm ~/Library/Caches/com.apple.preferencepanes.cache

#Set correct ownership permissions
chown -R root\:wheel /System/Library/PreferencePanes

# Disable WaitingForLoginWindow
mv /usr/libexec/WaitingForLoginWindow /usr/libexec/WaitingForLoginWindow.backup

echo "Main files are finished."
break;;

[nN]* ) exit;;
* ) echo "y/n answer please.";;
esac
done

while true
do
	read -p "Do you wish to install the San Francisco font? This replaces the LucidaGrande font and you lose usage of it (y/n)" answer

	case $answer in
		[yY]* )
clear
echo "Backing up original font and installing replacement..."
# Change font
mv /System/Library/Fonts/LucidaGrande.dfont /System/Library/Fonts/LucidaGrande.dfont.backup

cp ./font/LucidaGrande.dfont /System/Library/Fonts/LucidaGrande.dfont
echo "Font installed."
break;;



		[nN]* ) 
diskutil repairPermissions /
clear
echo "Installation is finished. Rebooting..."
sleep 10
reboot
exit;;
* ) echo "y/n answer please.";;
esac
done

# Repair disk permissions
diskutil repairPermissions /
clear
echo "Installation is finished. Rebooting..."
sleep 10
reboot